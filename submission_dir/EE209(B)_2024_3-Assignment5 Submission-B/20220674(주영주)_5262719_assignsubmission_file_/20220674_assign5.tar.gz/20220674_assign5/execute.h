/*--------------------------------------------------------------------*/
/* 20220674 주영주                                                     */
/* Assignment5                                                        */
/* execute.h                                                          */
/*--------------------------------------------------------------------*/

#ifndef EXECUTE_INCLUDED
#define EXECUTE_INCLUDED

#include "dynarray.h"

int execute(DynArray_T oTokens);

#endif /* _EXECUTE_H_ */