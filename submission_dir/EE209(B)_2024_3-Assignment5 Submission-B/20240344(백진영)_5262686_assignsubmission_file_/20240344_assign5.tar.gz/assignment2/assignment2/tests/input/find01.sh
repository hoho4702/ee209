#!/bin/bash
./sgrep "*og*e" < files/google.txt
