#ifndef REDIRECTION_H
#define REDIRECTION_H

#include "dynarray.h"
#include "util.h"
#include "signal.h"

void execute_with_redirection(DynArray_T oTokens);

#endif // REDIRECTION_H
