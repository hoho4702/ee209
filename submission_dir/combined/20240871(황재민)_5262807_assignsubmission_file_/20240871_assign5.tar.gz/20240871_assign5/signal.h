#ifndef _SIGNAL_H_
#define _SIGNAL_H_
void sigquit_handler(int sig);
void sigalarm_handler(int sig);
#endif /* _SIGNAL_H_ */
