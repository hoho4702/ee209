#!/bin/bash
./sgrep Gogole < files/long.txt
