#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#include "dynarray.h"
#include "util.h"
#include <unistd.h>

void
errorPrint(char *input, enum PrintMode mode) {
  static char *ishname = NULL;

  if (mode == SETUP)
    ishname = input;
  else {
    if (ishname == NULL)
      fprintf(stderr, "[WARN] Shell name is not set. Please fix this bug in main function\n");
    if (mode == PERROR) {
      if (input == NULL)
        fprintf(stderr, "%s: %s\n", ishname, strerror(errno));
      else
        fprintf(stderr, "%s: %s\n", input, strerror(errno));
    }
    else if (mode == FPRINTF)
      fprintf(stderr, "%s: %s\n", ishname, input);
    else if( mode == ALIAS)
      fprintf(stderr, "%s: alias: %s: not found\n", ishname, input);
    else
      fprintf(stderr, "mode %d not supported in errorPrint\n", mode);
    }
}

enum BuiltinType
checkBuiltin(struct Token *t) {
  /* Check null input before using string functions  */
  assert(t);
  assert(t->pcValue);

  if (strncmp(t->pcValue, "cd", 2) == 0 && strlen(t->pcValue) == 2)
    return B_CD;
  if (strncmp(t->pcValue, "fg", 2) == 0 && strlen(t->pcValue) == 2)
    return B_FG;
  if (strncmp(t->pcValue, "exit", 4) == 0 && strlen(t->pcValue) == 4)
    return B_EXIT;
  else if (strncmp(t->pcValue, "setenv", 6) == 0 && strlen(t->pcValue) == 6)
    return B_SETENV;
  else if (strncmp(t->pcValue, "unsetenv", 8) == 0 && strlen(t->pcValue) == 8)
    return B_USETENV;
  else if (strncmp(t->pcValue, "alias" , 5) == 0 && strlen(t->pcValue) == 5) 
    return B_ALIAS;
  else
    return NORMAL;
}

int
countPipe(DynArray_T oTokens) {
  int cnt = 0, i;
  struct Token *t;

  for (i = 0; i < DynArray_getLength(oTokens); i++) {
    t = DynArray_get(oTokens, i);
    if (t->eType == TOKEN_PIPE)
      cnt++;
  }

  return cnt;
}

/* Check background Command */
int
checkBG(DynArray_T oTokens) {
  int i;
  struct Token *t;

  for (i = 0; i < DynArray_getLength(oTokens); i++) {
    t = DynArray_get(oTokens, i);
    if (t->eType == TOKEN_BG)
      return 1;
  }
  return 0;
}

const char* specialTokenToStr(struct Token* psToken) {
  switch(psToken->eType) {
    case TOKEN_PIPE:
      return "TOKEN_PIPE(|)";
      break;
    case TOKEN_REDIN:
      return "TOKEN_REDIRECTION_IN(<)";
      break;
    case TOKEN_REDOUT:
      return "TOKEN_REDIRECTION_OUT(>)";
      break;
    case TOKEN_BG:
      return "TOKEN_BACKGROUND(&)";
      break;
    case TOKEN_WORD:
      /* This should not be called with TOKEN_WORD */
    default:
      assert(0 && "Unreachable");
      return NULL;
  }
}

void
dumpLex(DynArray_T oTokens) {
  if (getenv("DEBUG") != NULL) {
    int i;
    struct Token *t;

    for (i = 0; i < DynArray_getLength(oTokens); i++) {
      t = DynArray_get(oTokens, i);
      if (t->pcValue == NULL)
        fprintf(stderr, "[%d] %s\n", i, specialTokenToStr(t));
      else
        fprintf(stderr, "[%d] TOKEN_WORD(\"%s\")\n", i, t->pcValue);
    }
  }
}


void runBuiltinCommand(enum BuiltinType cmdType, DynArray_T tokensList) {
  int tokenCount = DynArray_getLength(tokensList);

  switch (cmdType) {
    case B_CD: {
        if (tokenCount > 2) {
            errorPrint("cd takes one parameter", FPRINTF);
            break;
        } 
        else if (tokenCount == 1) {
            const char* homePath = getenv("HOME");
            if (chdir(homePath) == -1) {
                errorPrint(NULL, PERROR);
            }
            break;
        } 
        else {
            const char* targetDir =
                ((struct Token *)DynArray_get(tokensList, 1))->pcValue;
            if (chdir(targetDir) == -1) {
                errorPrint(NULL, PERROR);
            }
            break;
        }
    }

    case B_EXIT: {
        if (tokenCount > 1) {
            errorPrint("exit takes no parameter", FPRINTF);
            break;
        } 
        else {
            printf("\n");
            DynArray_free(tokensList);
            exit(EXIT_SUCCESS);
        }
    }

    case B_SETENV: {
        if (tokenCount > 3 || tokenCount == 1) {
            errorPrint("setenv takes one or two parameter", FPRINTF);
            break;
        }
        else if (tokenCount == 2) {
            const char* varName =
                ((struct Token *)DynArray_get(tokensList, 1))->pcValue;
            setenv(varName, "", 1);
            break;
        }
        else {
            const char* varName =
                ((struct Token *)DynArray_get(tokensList, 1))->pcValue;
            const char* varValue =
                ((struct Token *)DynArray_get(tokensList, 2))->pcValue;
            setenv(varName, varValue, 1);
            break;
        }
    }

    case B_USETENV: {
        if (tokenCount != 2) {
            errorPrint("unsetenv takes one parameter", FPRINTF);
            break;
        }
        else {
            const char* varName =
                ((struct Token *)DynArray_get(tokensList, 1))->pcValue;
            if (getenv(varName) != NULL) {
                unsetenv(varName);
            }
            break;
        }
    }

    default:
        assert(0 && "Unreachable");
    }
}
