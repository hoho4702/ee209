#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>     /* 문자열 처리에 사용 */
#include <unistd.h>     /* getenv 등의 함수에 사용 */
#include <limits.h>     /* PATH_MAX 상수 등 */
#include <sys/types.h>
#include <sys/wait.h>   /* waitpid */
#include <fcntl.h>      /* open, O_RDWR 등 */
#include <signal.h>     /* signal, sigaction */
#include <time.h>       /* time() */

#include "lexsyn.h"
#include "util.h"
#include "dynarray.h"   /* 가정: DynArray_new/free 등 선언 */

#ifndef MAX_LINE_SIZE
#define MAX_LINE_SIZE 1024
#endif

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

static const char* g_pszProgName = "ish"; /* 기본값. main()에서 덮어씀 */

/* Ctrl-\ 처리용 전역 변수 */
static volatile sig_atomic_t g_gotFirstSIGQUIT = 0; /* 첫 SIGQUIT 받았는지 여부 */
static time_t g_firstSIGQUITTime = 0;               /* 첫 SIGQUIT 받은 시각 */


static void printError(const char *msg)
{
    /* stderr에 출력. "ish: msg\n" 형태 */
    fprintf(stderr, "%s: %s\n", g_pszProgName, msg);
}


static void shellHelper(const char *inLine);
static void executeBuiltin(BuiltinType btype, DynArray_T oTokens, int hasRedir);
static void executeExternalCommand(DynArray_T oTokens, const char *inFile, const char *outFile);
static void executePipeline(DynArray_T oTokens);

/* 시그널 핸들러 관련 */
static void installSignalHandlers(void);
//static void sigintHandler(int signo);
static void sigquitHandler(int signo);

/*-------------------------------------------------------------------------*/
/* 시그널 핸들러 및 설치                                                   */
/*-------------------------------------------------------------------------*/

/* SIGINT 핸들러: 부모는 무시, 자식은 default이므로 사실상 부모코드에선 무시됨.
   => 여기서 굳이 뭔가 할 필요 없이 SIG_IGN으로 설정해도 됩니다.
   => 만약 핸들러 함수를 둔다면 아무 것도 안 해도 동일 효과. */

/* SIGQUIT 핸들러: 
   1) 처음 받으면 "Type Ctrl-\ again within 5 seconds to exit." 출력
   2) 5초 안에 다시 받으면 종료 */
static void sigquitHandler(int signo)
{
    (void)signo; 
    time_t now = time(NULL);

    if (!g_gotFirstSIGQUIT) {
        /* 첫 SIGQUIT 수신 */
        g_gotFirstSIGQUIT = 1;
        g_firstSIGQUITTime = now;
        fprintf(stdout, "Type Ctrl-\\ again within 5 seconds to exit.\n");
        fflush(stdout);
    }
    else {
        /* 이미 한 번 받은 상태 */
        double diff = difftime(now, g_firstSIGQUITTime);
        if (diff <= 5.0) {
            /* 5초 이내에 두 번째 Ctrl-\ => 종료 */
            fprintf(stdout, "Exiting...\n");
            fflush(stdout);
            exit(EXIT_SUCCESS);
        }
        else {
            /* 5초 넘었으면 다시 처음 상태로 리셋 */
            g_gotFirstSIGQUIT = 1;
            g_firstSIGQUITTime = now;
            fprintf(stdout, "Type Ctrl-\\ again within 5 seconds to exit.\n");
            fflush(stdout);
        }
    }
}

/* 부모 프로세스용 시그널 핸들러 설치 */
static void installSignalHandlers(void)
{
    /* SIGINT(Ctrl-C)는 부모는 무시 => SIG_IGN */
    signal(SIGINT, SIG_IGN);

    /* SIGQUIT(Ctrl-\)는 부모가 특별히 처리 => sigquitHandler */
    signal(SIGQUIT, sigquitHandler);
}

static void executeBuiltin(BuiltinType btype, DynArray_T oTokens, int hasRedir)
{
    /* 빌트인에서 리다이렉션이 걸려있으면 에러 메시지 후 무시 */
    if (hasRedir) {
        printError("No redirection allowed with builtin commands");
        return;
    }

    size_t tokenCount = DynArray_getLength(oTokens);

    switch (btype) {
        case BUILTIN_CD: {
            /* cd [dir] */
            if (tokenCount == 1) {
                /* 인자가 없으면 HOME 이동 */
                char *homeDir = getenv("HOME");
                if (homeDir == NULL) {
                    printError("HOME not set");
                    return;
                }
                if (chdir(homeDir) != 0) {
                    perror("cd");
                }
            }
            else {
                /* cd dir */
                struct Token *tok = DynArray_get(oTokens, 1);
                if (chdir(tok->pcValue) != 0) {
                    perror("cd");
                }
            }
            break;
        }

        case BUILTIN_SETENV: {
            /* setenv var [value] */
            if (tokenCount < 2) {
                printError("Usage: setenv var [value]");
                return;
            }
            struct Token *varTok = DynArray_get(oTokens, 1);
            const char *var = varTok->pcValue;
            
            const char *val = "";
            if (tokenCount >= 3) {
                struct Token *valTok = DynArray_get(oTokens, 2);
                val = valTok->pcValue;
            }
            if (setenv(var, val, 1) != 0) {
                perror("setenv");
            }
            break;
        }

        case BUILTIN_UNSETENV: {
            /* unsetenv var */
            if (tokenCount < 2) {
                printError("Usage: unsetenv var");
                return;
            }
            struct Token *varTok = DynArray_get(oTokens, 1);
            if (unsetenv(varTok->pcValue) != 0) {
                perror("unsetenv");
            }
            break;
        }

        case BUILTIN_EXIT:
            exit(EXIT_SUCCESS);

        case BUILTIN_NONE:
        default:
            /* 여기는 오면 안 됨 */
            break;
    }
}

static void executeExternalCommand(DynArray_T oTokens, const char *inFile, const char *outFile)
{
    pid_t pid;
    size_t tokenCount = DynArray_getLength(oTokens);

    /* execvp에 들어갈 argv 배열 준비 */
    char **argv = calloc(tokenCount + 1, sizeof(char*));
    if (argv == NULL) {
        printError("Cannot allocate memory for argv");
        return;
    }
    size_t argIndex = 0;
    for (size_t i = 0; i < tokenCount; i++) {
        struct Token *tok = DynArray_get(oTokens, i);
        if (tok->eType == TOKEN_REDOUT || tok->eType == TOKEN_REDIN) {
            i++; /* 다음 토큰은 파일 이름이므로 건너뛰기 */
            continue;
        }
        argv[argIndex++] = tok->pcValue;
    }
    argv[tokenCount] = NULL;

    pid = fork();
    if (pid < 0) {
        perror("fork");
        free(argv);
        return;
    }
    else if (pid == 0) {
        /* 자식 프로세스: SIGINT, SIGQUIT를 default로 복구해서
           Ctrl-C, Ctrl-\ 시 자식은 종료 가능 */
        signal(SIGINT, SIG_DFL);
        signal(SIGQUIT, SIG_DFL);

        /* 표준 입력 리다이렉션 */
        if (inFile != NULL) {
            int fdIn = open(inFile, O_RDONLY);
            if (fdIn < 0) {
                /* 명세: 없는 파일이면 에러 메시지 */
                fprintf(stderr, "%s: cannot open file %s for input\n", g_pszProgName, inFile);
                free(argv);
                exit(EXIT_FAILURE);
            }
            dup2(fdIn, STDIN_FILENO);
            close(fdIn);
        }

        /* 표준 출력 리다이렉션 (0600 권한으로 생성) */
        if (outFile != NULL) {
            int fdOut = open(outFile, O_WRONLY | O_CREAT | O_TRUNC, 0600);
            if (fdOut < 0) {
                fprintf(stderr, "%s: cannot open file %s for output\n", g_pszProgName, outFile);
                free(argv);
                exit(EXIT_FAILURE);
            }
            dup2(fdOut, STDOUT_FILENO);
            close(fdOut);
        }

        /* execvp */
        execvp(argv[0], argv);

        /* execvp 실패 시 에러 메시지 */
        perror(argv[0]);
        free(argv);
        exit(EXIT_FAILURE);
    }
    else {
        /* 부모 프로세스는 항상 wait */
        free(argv);
        int status;
        waitpid(pid, &status, 0);
    }
}

static void executePipeline(DynArray_T oTokens)
{
    /*
      이미 syntaxCheck()가 성공이라고 판단한 상태에서만 이 함수를 호출.
      따라서 여기서는 "missing command name" 같은 문법 오류 메세지를
      굳이 찍지 않는다.
    */

    /* 1) 파이프 '|' 기준으로 서브커맨드 분할 */
    DynArray_T subcmds = DynArray_new(0);
    if (!subcmds) {
        printError("Cannot allocate memory for pipeline");
        return;
    }

    DynArray_T current = DynArray_new(0);
    if (!current) {
        DynArray_free(subcmds);
        printError("Cannot allocate memory");
        return;
    }

    size_t totalTokens = DynArray_getLength(oTokens);
    for (size_t i = 0; i < totalTokens; i++) {
        struct Token *tok = DynArray_get(oTokens, i);
        if (tok->eType == TOKEN_PIPE) {
            /* 여기서는 "Invalid pipeline ..." 메시지를 제거 */
            DynArray_add(subcmds, current);
            current = DynArray_new(0);
            if (!current) {
                printError("Cannot allocate memory");
                /* 간단 처리 */
                return;
            }
        }
        else {
            DynArray_add(current, tok);
        }
    }
    DynArray_add(subcmds, current);

    /* 2) 파이프 배열 생성 */
    size_t subcmdCount = DynArray_getLength(subcmds);
    int pipeCount = (int)subcmdCount - 1;
    int pipes[pipeCount][2];

    for (int p = 0; p < pipeCount; p++) {
        if (pipe(pipes[p]) < 0) {
            perror("pipe");
            /* 간단 처리 */
            return;
        }
    }

    /* 3) 각 서브커맨드 fork+exec */
    for (size_t idx = 0; idx < subcmdCount; idx++) {
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            continue;
        }
        else if (pid == 0) {
            /* 자식 */
            signal(SIGINT, SIG_DFL);
            signal(SIGQUIT, SIG_DFL);

            /* stdin 설정 */
            if (idx > 0) {
                dup2(pipes[idx-1][0], STDIN_FILENO);
            }
            /* stdout 설정 */
            if (idx < subcmdCount - 1) {
                dup2(pipes[idx][1], STDOUT_FILENO);
            }

            /* 부모가 쓰는 파이프 FD 닫기 */
            for (int k = 0; k < pipeCount; k++) {
                close(pipes[k][0]);
                close(pipes[k][1]);
            }

            /* exec */
            DynArray_T cmdTokens = DynArray_get(subcmds, idx);
            size_t ccount = DynArray_getLength(cmdTokens);
            char **argv = calloc(ccount + 1, sizeof(char*));
            if (!argv) {
                printError("Cannot allocate memory for pipeline argv");
                exit(EXIT_FAILURE);
            }
            for (size_t c = 0; c < ccount; c++) {
                struct Token *t = DynArray_get(cmdTokens, c);
                argv[c] = t->pcValue; 
            }
            argv[ccount] = NULL;

            execvp(argv[0], argv);
            perror(argv[0]);
            free(argv);
            exit(EXIT_FAILURE);
        }
        else {
            /* 부모 */
        }
    }

    /* 부모: 모든 파이프 FD 닫기 */
    for (int p = 0; p < pipeCount; p++) {
        close(pipes[p][0]);
        close(pipes[p][1]);
    }

    /* 자식들 기다리기 */
    for (size_t i = 0; i < subcmdCount; i++) {
        int status;
        wait(&status);
    }

    /* subcmds 정리 */
    for (size_t k = 0; k < subcmdCount; k++) {
        DynArray_free(DynArray_get(subcmds, k));
    }
    DynArray_free(subcmds);
}

static void shellHelper(const char *inLine) 
{
    DynArray_T oTokens = DynArray_new(0);
    if (oTokens == NULL) {
        printError("Cannot allocate memory");
        exit(EXIT_FAILURE);
    }

    enum LexResult lexcheck = lexLine(inLine, oTokens);
    if (lexcheck == LEX_SUCCESS) {
        if (DynArray_getLength(oTokens) == 0) {
            DynArray_free(oTokens);
            return;
        }

        /*-----------------------------------------------------------
          1) 문법 체크 먼저
        -----------------------------------------------------------*/
        enum SyntaxResult syncheck = syntaxCheck(oTokens);

        if (syncheck == SYN_SUCCESS) {
            /*------------------------------------------------------
              2) 파이프 존재 여부 확인 -> 파이프 있으면 executePipeline()
                 없으면 빌트인/외부명령 처리
            ------------------------------------------------------*/
            bool hasPipe = false;
            size_t len = DynArray_getLength(oTokens);
            for (size_t i = 0; i < len; i++) {
                struct Token *tok = DynArray_get(oTokens, i);
                if (tok->eType == TOKEN_PIPE) {
                    hasPipe = true;
                    break;
                }
            }

            /* 백그라운드는 무시(또는 에러) */
            int background = getBackground();
            if (background) {
                printError("Background execution is not supported, ignoring '&'");
            }

            /* 리다이렉션 파일 */
            const char *inFile  = NULL;
            const char *outFile = NULL;

            for (size_t i = 0; i < len; i++) {
                struct Token *tok = DynArray_get(oTokens, i);
                if (tok->eType == TOKEN_REDIN) {
                    // i+1 번 토큰이 진짜 파일 이름
                    if (i+1 < len) {
                        struct Token *fileTok = DynArray_get(oTokens, i+1);
                        inFile = fileTok->pcValue; 
                    }
                }
                else if (tok->eType == TOKEN_REDOUT) {
                    if (i+1 < len) {
                        struct Token *fileTok = DynArray_get(oTokens, i+1);
                        outFile = fileTok->pcValue;
                    }
                }
            }

            int hasRedir = (inFile != NULL || outFile != NULL);

            BuiltinType btype = checkBuiltin(DynArray_get(oTokens, 0));

            if (hasPipe) {
                /* 파이프 실행 */
                executePipeline(oTokens);
            }
            else {
                /* 빌트인 or 외부 명령 처리 */
                if (btype != BUILTIN_NONE) {
                    executeBuiltin(btype, oTokens, hasRedir);
                }
                else {
                    executeExternalCommand(oTokens, inFile, outFile);
                }
            }
        }
        else {
            /*------------------------------------------------------
              3) 문법 오류 상황 -> 오류 메시지 출력
            ------------------------------------------------------*/
            if (syncheck == SYN_FAIL_NOCMD) {
                printError("Missing command name");
            }
            else if (syncheck == SYN_FAIL_MULTREDOUT) {
                printError("Multiple redirection of standard out");
            }
            else if (syncheck == SYN_FAIL_NODESTOUT) {
                printError("Standard output redirection without file name");
            }
            else if (syncheck == SYN_FAIL_MULTREDIN) {
                printError("Multiple redirection of standard input");
            }
            else if (syncheck == SYN_FAIL_NODESTIN) {
                printError("Standard input redirection without file name");
            }
            else if (syncheck == SYN_FAIL_INVALIDBG) {
                printError("Invalid use of background");
            }
            /* 필요하다면 다른 케이스도 추가 */
        }
    }
    else {
        /*-----------------------------------------------------------
          4) 렉서(lexLine) 오류 상황
        -----------------------------------------------------------*/
        if (lexcheck == LEX_QERROR) {
            printError("Unmatched quote");
        }
        else if (lexcheck == LEX_NOMEM) {
            printError("Cannot allocate memory");
        }
        else if (lexcheck == LEX_LONG) {
            printError("Command is too large");
        }
        else {
            printError("lexLine needs to be fixed");
            exit(EXIT_FAILURE);
        }
    }

    DynArray_free(oTokens);
}


int main(int argc, char *argv[]){
    if (argc > 0) {
        g_pszProgName = argv[0];
    }
    installSignalHandlers();

    char acLine[MAX_LINE_SIZE + 2];
    char *homeDir = getenv("HOME");
    if (homeDir != NULL) {
        char rcPath[PATH_MAX];
        snprintf(rcPath, PATH_MAX, "%s/.ishrc", homeDir);

        FILE *rcFile = fopen(rcPath, "r");
        if (rcFile != NULL) {
            while (fgets(acLine, MAX_LINE_SIZE, rcFile) != NULL) {
                /* 개행 제거 */
                size_t len = strlen(acLine);
                if (len > 0 && acLine[len-1] == '\n') {
                    acLine[len-1] = '\0';
                }
                /* 읽은 줄 출력 */
                fprintf(stdout, "%% %s\n", acLine);
                fflush(stdout);
                /* 해석 */
                shellHelper(acLine);
            }
            fclose(rcFile);
        }
    }

    while (1) {
        fprintf(stdout, "%% ");
        fflush(stdout);
        if (fgets(acLine, MAX_LINE_SIZE, stdin) == NULL) {
            printf("\n");
            exit(EXIT_SUCCESS);
        }
        size_t len = strlen(acLine);
        if (len > 0 && acLine[len-1] == '\n') {
            acLine[len-1] = '\0';
        }
        shellHelper(acLine);
    }
    return 0;
}