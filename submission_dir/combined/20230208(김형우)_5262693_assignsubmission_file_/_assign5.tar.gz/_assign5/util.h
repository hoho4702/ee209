#ifndef _UTIL_H_
#define _UTIL_H_

#include "token.h"
#include "dynarray.h"

enum {FALSE, TRUE};

typedef enum {
  BUILTIN_NONE,      /* 일반 명령어 */
  BUILTIN_CD,
  BUILTIN_SETENV,
  BUILTIN_UNSETENV,
  BUILTIN_EXIT,
  BUILTIN_FG,
  BUILTIN_ALIAS
} BuiltinType;
// enum BuiltinType {NORMAL, B_EXIT, B_SETENV, B_USETENV, B_CD, B_ALIAS, B_FG};
enum PrintMode {SETUP, PERROR, FPRINTF, ALIAS};

void errorPrint(char *input, enum PrintMode mode);
BuiltinType checkBuiltin(struct Token *t);
int countPipe(DynArray_T oTokens);
int checkBG(DynArray_T oTokens);
void dumpLex(DynArray_T oTokens);

int getBackground(void);
const char* getInFile(void);
const char* getOutFile(void);

#endif /* _UTIL_H_ */
